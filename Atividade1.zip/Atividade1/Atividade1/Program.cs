﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atividade1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] vet = new int[12];
            vet[0] = 18;
            vet[1] = 3;
            vet[2] = 97;
            vet[3] = 1;
            vet[4] = 52;
            vet[5] = 0;
            vet[6] = 43;
            vet[7] = 13;
            vet[8] = 7;
            vet[9] = 16;
            vet[10] = 21;
            vet[11] = 22;

            int aux = 0, cont = 0;

            Console.WriteLine("--------------------------");

            Console.WriteLine("Antes: ");
            for (int i = 0; i <= 11; i++)
            {
                Console.WriteLine(" " + vet[i] + " ");
            }

            Console.WriteLine("--------------------------");
            //Console.WriteLine("Loops: ");

            for (int i = 0; i <= 11; i++)
            {
                for (int j = 0; j < 11; j++)
                {
                    if (vet[j] > vet[j + 1])
                    {
                        Console.WriteLine("- Trocou! -> " + vet[j] + " é maior que " + vet[j + 1]);

                        aux = vet[j + 1];
                        vet[j + 1] = vet[j];
                        vet[j] = aux;
                        cont++;

                        Console.WriteLine();
                    }

                }
            }

            Console.WriteLine("--------------------------");
            Console.WriteLine("Depois: ");
            for (int i = 0; i <= 11; i++)
            {
                Console.WriteLine(" " + vet[i] + " ");
            }
            Console.WriteLine("--------------------------");

            Console.WriteLine("Foram realizados " + cont + " loops!");

            Console.WriteLine("--------------------------");
        }
    }
}
