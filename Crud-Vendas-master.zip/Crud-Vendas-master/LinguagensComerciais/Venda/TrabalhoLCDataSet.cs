﻿namespace Venda
{


    public partial class TrabalhoLCDataSet
    {
    }
}
