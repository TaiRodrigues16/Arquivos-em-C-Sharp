﻿using System;

namespace Biblioteca
{
    public class Produto
    {
        /// <summary>
        /// Chave primária do produto
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        /// Nome do produto
        /// </summary>
        public string Descricao { get; set; }

        /// <summary>
        /// Margem em Porcentagem
        /// </summary>
        public decimal Margem { get; set; }

        public DateTime Fabricacao { get; set; }

        public int Validade { get; set; }

        public decimal Preco { get; set; }

        /// <summary>
        /// Construtora
        /// </summary>
        public Produto()
        {
            ID = 0;
            Descricao = "";
            Margem = 10;
            Fabricacao = DateTime.MinValue;
            Validade = 0;
            Preco = 0;
        }

        public Produto(int id, string descricao, decimal margem, DateTime fabricacao, int validade, decimal preco)
        {
            ID = id;
            Descricao = descricao;
            Margem = margem;
            Fabricacao = fabricacao;
            Validade = validade;
            Preco = preco;
        }

        public decimal ObterPreco()
        {
            return Preco + (Preco * (Margem / 100));
        }

        public DateTime ObterValidade()
        {
            return Fabricacao.AddMonths(Validade);
        }
    }
}
