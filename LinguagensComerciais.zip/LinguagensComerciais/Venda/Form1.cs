﻿using System;
using Biblioteca;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Venda
{
    public partial class venda : Form
    {
        public List<Produto> listaProdutos { get; set; }

        public venda()
        {
            listaProdutos = new List<Produto>();

            Produto novo = new Produto(1, "Coca Cola", 25, DateTime.Now.AddDays(-165), 6, 2);
            listaProdutos.Add(novo);

            novo = new Produto(2, "Pepsi", 5, DateTime.Now.AddDays(-75), 24, 1);
            listaProdutos.Add(novo);

            novo = new Produto(3, "Sukita", 12, DateTime.Now.AddDays(-68), 5, 1.2m);
            listaProdutos.Add(novo);

            InitializeComponent();

        }

        private void incluirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Produto: " + listaProdutos.First().Descricao + System.Environment.NewLine + "Validade: " + listaProdutos.First().ObterValidade());
        }

        private void consultarToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void excluirToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void editarToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
