﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Função
{
    class Program
    {
        /*Exercícios
         *1)
         * Crie uma função "JogarDados" para uma jogada de dados. a função deve sortear um numero de 1 a 7 Random e a método Next
         * A função deve receber o número escolhido pelo jogador, comparar com o valor sorteado e retornar true se o jogador acertou e false se o jogador errou.
         * 
         * 2)
         * Implementar uma função POW que recebe dois valores inteiros, o segundo é o espoente do primeiro. Exemplo: POW(2,3) vai retornar 8.
         * */


        static void Main(string[] args)
        {

            //1)
            int jogador = 3;
            if (JogarDados(jogador) == true)
            {
                Console.WriteLine("Ganhou!");
            }
            else
            {
                Console.WriteLine("Perdeu!");
            }

            //2
            int valor1;
            int valor2;

            Console.Write("Informe o primeiro valor: ");
            valor1 = int.Parse(Console.ReadLine());
            Console.Write("Informe o primeiro valor: ");
            valor2 = int.Parse(Console.ReadLine());

            //3
            Console.WriteLine(valor1 + " elevado a " + valor2 + " : " + POW(valor1, valor2));
            //4
            Console.WriteLine("Fernanda: " + Troca("Fernanda", 'a', 'o'));

            //5 
            int temperatura;
            Console.Write("Informe uma temperatura: ");
            temperatura = int.Parse(Console.ReadLine());

            Console.WriteLine("Sua temperatura eh: "+ FatorItuiutaba(temperatura));
        }

        static int FatorItuiutaba(int temperatura)
        {
            /*
             * Criar uma função que recebe uma temperatura normal e retorna este valor multiplicado por 2;
            */
            int tempMult = 0;
            tempMult = temperatura * 2;

            return tempMult;
        }

        static string Troca(string nome, char letra1, char letra2)
        {
            nome = nome.Replace(letra1, letra2);
            return nome;
        }

        static int POW(int valor1, int valor2)
        {
            int resposta = 1;
            for (int i = 0; i < valor2; i++)
            {
                resposta = resposta * valor1;
            }

            return resposta;
        }

        public static bool JogarDados(int sorteado)
        {
            bool resposta = false;
            Random dado = new Random();
            int sorteio = dado.Next(1, 6);
            Console.WriteLine("Numero sorteado: " + sorteio);
            if (sorteado == sorteio)
            {
                resposta = true;
            }

            return resposta;
        }

    }
}
