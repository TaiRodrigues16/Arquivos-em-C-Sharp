﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class Form1 : Form
    {
        public enum Operador
        {
            soma,
            multiplicacao,
            divisao,
            subtracao,
            indefinido
        }

        public Operador operador { get; set; }
        public decimal operando1 { get; set; }
        public decimal operando2 { get; set; }
        public bool acumulando { get; set; }
        public bool zerar { get; set; }

        public Form1()
        {
            InitializeComponent();

            operando1 = 0;
            operando2 = 0;
            operador = Operador.indefinido;
            acumulando = false;
            zerar = false;
        }

        private void umButton_Click(object sender, EventArgs e)
        {
            var myButton = (Button)sender;
            if (displayLabel.Text.Length < 12)
            {
                if ((displayLabel.Text == "0") || acumulando)
                {
                    displayLabel.Text = myButton.Text;
                }
                else
                {
                    displayLabel.Text += myButton.Text;
                }
            }

            acumulando = false;
            zerar = false;
        }

        private void maisButton_Click(object sender, EventArgs e)
        {
            if (operando1 != 0)
            {
                acumulando = true;
            }
            else
            {
                acumulando = false;
            }

            operando1 = ValorOperando1(Operador.soma);
            if (operando1 != 0)
            {
                operador = Operador.soma;
                if (acumulando)
                {
                    displayLabel.Text = operando1.ToString();
                }
                else
                {
                    displayLabel.Text = "0";
                }

            }
        }

        private void menosButton_Click(object sender, EventArgs e)
        {
            if (operando1 != 0)
            {
                acumulando = true;
            }
            else
            {
                acumulando = false;
            }

            operando1 = ValorOperando1(Operador.subtracao);
            if (operando1 != 0)
            {
                operador = Operador.subtracao;
                if (acumulando)
                {
                    displayLabel.Text = operando1.ToString();
                }
                else
                {
                    displayLabel.Text = "0";
                }

            }
        }

        private void multiButton_Click(object sender, EventArgs e)
        {
            if (operando1 != 0)
            {
                acumulando = true;
            }
            else
            {
                acumulando = false;
            }

            operando1 = ValorOperando1(Operador.multiplicacao);
            if (operando1 != 0)
            {
                operador = Operador.multiplicacao;
                if (acumulando)
                {
                    displayLabel.Text = operando1.ToString();
                }
                else
                {
                    displayLabel.Text = "0";
                }

            }
        }

        private void divButton_Click(object sender, EventArgs e)
        {
            if (operando1 != 0)
            {
                acumulando = true;
            }
            else
            {
                acumulando = false;
            }

            operando1 = ValorOperando1(Operador.divisao);
            if (operando1 != 0)
            {
                operador = Operador.divisao;
                if (acumulando)
                {
                    displayLabel.Text = operando1.ToString();
                }
                else
                {
                    displayLabel.Text = "0";
                }

            }
        }

        private decimal ValorOperando1(Operador operacao)
        {
            decimal valorRetorno = 0;

            if (displayLabel.Text != "0")
            {
                valorRetorno = decimal.Parse(displayLabel.Text);
                if (operando1 != 0)
                {
                    switch (operacao)
                    {
                        case Operador.soma:
                            valorRetorno += operando1;
                            break;
                        case Operador.multiplicacao:
                            valorRetorno *= operando1;
                            break;
                        case Operador.divisao:
                            valorRetorno = operando1 / valorRetorno;
                            break;
                        case Operador.subtracao:
                            valorRetorno = operando1 - valorRetorno;
                            break;
                        case Operador.indefinido:
                            break;
                        default:
                            break;
                    }

                }
            }

            return valorRetorno;
        }

        private void igualButton_Click(object sender, EventArgs e)
        {
            if (operando1 != 0)
            {
                if (displayLabel.Text != "0")
                {

                    operando2 = decimal.Parse(displayLabel.Text);
                    switch (operador)
                    {
                        case Operador.soma:
                            decimal resultado = operando1 + operando2;
                            displayLabel.Text = resultado.ToString();
                            break;
                        case Operador.multiplicacao:
                            decimal resultadoMulti = operando1 * operando2;
                            displayLabel.Text = resultadoMulti.ToString();
                            break;
                        case Operador.divisao:
                            decimal resultadoDiv = operando1 / operando2;
                            displayLabel.Text = resultadoDiv.ToString();
                            break;
                        case Operador.subtracao:
                            decimal resultadoSub = operando1 - operando2;
                            displayLabel.Text = resultadoSub.ToString();
                            break;
                        default:
                            break;
                    }

                    operando1 = 0;
                    operando2 = 0;
                    operador = Operador.indefinido;
                    zerar = true;
                }
            }
        }

        private void cButton_Click(object sender, EventArgs e)
        {
            operando1 = 0;
            operando2 = 0;
            displayLabel.Text = "0";
        }

        private void ceButton_Click(object sender, EventArgs e)
        {
            displayLabel.Text = "0";
            operando2 = 0;
        }

        private void percentButton_Click(object sender, EventArgs e)
        {
            //decimal resul = operando2 * 
            decimal perc = operando2 / 100;
            decimal resultado = operando1 - ((operando1 * perc) / 100);
            displayLabel.Text = resultado.ToString();



            //v = v - ((v * per)/ 100)
        }
    }
}
