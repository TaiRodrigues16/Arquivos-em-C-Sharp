﻿namespace Calculadora
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.displayLabel = new System.Windows.Forms.Label();
            this.ceButton = new System.Windows.Forms.Button();
            this.cButton = new System.Windows.Forms.Button();
            this.noveButton = new System.Windows.Forms.Button();
            this.oitoButton = new System.Windows.Forms.Button();
            this.seteButton = new System.Windows.Forms.Button();
            this.umButton = new System.Windows.Forms.Button();
            this.seisButton = new System.Windows.Forms.Button();
            this.cincoButton = new System.Windows.Forms.Button();
            this.quatroButton = new System.Windows.Forms.Button();
            this.zeroButton = new System.Windows.Forms.Button();
            this.tresButton = new System.Windows.Forms.Button();
            this.doisButton = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.divButton = new System.Windows.Forms.Button();
            this.multiButton = new System.Windows.Forms.Button();
            this.maisButton = new System.Windows.Forms.Button();
            this.menosButton = new System.Windows.Forms.Button();
            this.percentButton = new System.Windows.Forms.Button();
            this.igualButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // displayLabel
            // 
            this.displayLabel.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.displayLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.displayLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.displayLabel.Location = new System.Drawing.Point(3, 2);
            this.displayLabel.Name = "displayLabel";
            this.displayLabel.Size = new System.Drawing.Size(286, 50);
            this.displayLabel.TabIndex = 0;
            this.displayLabel.Text = "0";
            this.displayLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ceButton
            // 
            this.ceButton.Location = new System.Drawing.Point(59, 69);
            this.ceButton.Name = "ceButton";
            this.ceButton.Size = new System.Drawing.Size(50, 42);
            this.ceButton.TabIndex = 1;
            this.ceButton.Text = "CE";
            this.ceButton.UseVisualStyleBackColor = true;
            this.ceButton.Click += new System.EventHandler(this.ceButton_Click);
            // 
            // cButton
            // 
            this.cButton.Location = new System.Drawing.Point(115, 69);
            this.cButton.Name = "cButton";
            this.cButton.Size = new System.Drawing.Size(50, 42);
            this.cButton.TabIndex = 2;
            this.cButton.Text = "C";
            this.cButton.UseVisualStyleBackColor = true;
            this.cButton.Click += new System.EventHandler(this.cButton_Click);
            // 
            // noveButton
            // 
            this.noveButton.Location = new System.Drawing.Point(115, 115);
            this.noveButton.Name = "noveButton";
            this.noveButton.Size = new System.Drawing.Size(50, 42);
            this.noveButton.TabIndex = 3;
            this.noveButton.Text = "9";
            this.noveButton.UseVisualStyleBackColor = true;
            this.noveButton.Click += new System.EventHandler(this.umButton_Click);
            // 
            // oitoButton
            // 
            this.oitoButton.Location = new System.Drawing.Point(59, 115);
            this.oitoButton.Name = "oitoButton";
            this.oitoButton.Size = new System.Drawing.Size(50, 42);
            this.oitoButton.TabIndex = 4;
            this.oitoButton.Text = "8";
            this.oitoButton.UseVisualStyleBackColor = true;
            this.oitoButton.Click += new System.EventHandler(this.umButton_Click);
            // 
            // seteButton
            // 
            this.seteButton.Location = new System.Drawing.Point(3, 115);
            this.seteButton.Name = "seteButton";
            this.seteButton.Size = new System.Drawing.Size(50, 42);
            this.seteButton.TabIndex = 5;
            this.seteButton.Text = "7";
            this.seteButton.UseVisualStyleBackColor = true;
            this.seteButton.Click += new System.EventHandler(this.umButton_Click);
            // 
            // umButton
            // 
            this.umButton.Location = new System.Drawing.Point(3, 211);
            this.umButton.Name = "umButton";
            this.umButton.Size = new System.Drawing.Size(50, 42);
            this.umButton.TabIndex = 6;
            this.umButton.Text = "1";
            this.umButton.UseVisualStyleBackColor = true;
            this.umButton.Click += new System.EventHandler(this.umButton_Click);
            // 
            // seisButton
            // 
            this.seisButton.Location = new System.Drawing.Point(115, 163);
            this.seisButton.Name = "seisButton";
            this.seisButton.Size = new System.Drawing.Size(50, 42);
            this.seisButton.TabIndex = 7;
            this.seisButton.Text = "6";
            this.seisButton.UseVisualStyleBackColor = true;
            this.seisButton.Click += new System.EventHandler(this.umButton_Click);
            // 
            // cincoButton
            // 
            this.cincoButton.Location = new System.Drawing.Point(59, 163);
            this.cincoButton.Name = "cincoButton";
            this.cincoButton.Size = new System.Drawing.Size(50, 42);
            this.cincoButton.TabIndex = 8;
            this.cincoButton.Text = "5";
            this.cincoButton.UseVisualStyleBackColor = true;
            this.cincoButton.Click += new System.EventHandler(this.umButton_Click);
            // 
            // quatroButton
            // 
            this.quatroButton.Location = new System.Drawing.Point(3, 163);
            this.quatroButton.Name = "quatroButton";
            this.quatroButton.Size = new System.Drawing.Size(50, 42);
            this.quatroButton.TabIndex = 9;
            this.quatroButton.Text = "4";
            this.quatroButton.UseVisualStyleBackColor = true;
            this.quatroButton.Click += new System.EventHandler(this.umButton_Click);
            // 
            // zeroButton
            // 
            this.zeroButton.Location = new System.Drawing.Point(3, 259);
            this.zeroButton.Name = "zeroButton";
            this.zeroButton.Size = new System.Drawing.Size(106, 42);
            this.zeroButton.TabIndex = 10;
            this.zeroButton.Text = "0";
            this.zeroButton.UseVisualStyleBackColor = true;
            this.zeroButton.Click += new System.EventHandler(this.umButton_Click);
            // 
            // tresButton
            // 
            this.tresButton.Location = new System.Drawing.Point(115, 211);
            this.tresButton.Name = "tresButton";
            this.tresButton.Size = new System.Drawing.Size(50, 42);
            this.tresButton.TabIndex = 11;
            this.tresButton.Text = "3";
            this.tresButton.UseVisualStyleBackColor = true;
            this.tresButton.Click += new System.EventHandler(this.umButton_Click);
            // 
            // doisButton
            // 
            this.doisButton.Location = new System.Drawing.Point(59, 211);
            this.doisButton.Name = "doisButton";
            this.doisButton.Size = new System.Drawing.Size(50, 42);
            this.doisButton.TabIndex = 12;
            this.doisButton.Text = "2";
            this.doisButton.UseVisualStyleBackColor = true;
            this.doisButton.Click += new System.EventHandler(this.umButton_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(115, 259);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(50, 42);
            this.button13.TabIndex = 13;
            this.button13.Text = ".";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // divButton
            // 
            this.divButton.Location = new System.Drawing.Point(171, 115);
            this.divButton.Name = "divButton";
            this.divButton.Size = new System.Drawing.Size(50, 42);
            this.divButton.TabIndex = 14;
            this.divButton.Text = "/";
            this.divButton.UseVisualStyleBackColor = true;
            this.divButton.Click += new System.EventHandler(this.divButton_Click);
            // 
            // multiButton
            // 
            this.multiButton.Location = new System.Drawing.Point(171, 163);
            this.multiButton.Name = "multiButton";
            this.multiButton.Size = new System.Drawing.Size(50, 42);
            this.multiButton.TabIndex = 15;
            this.multiButton.Text = "*";
            this.multiButton.UseVisualStyleBackColor = true;
            this.multiButton.Click += new System.EventHandler(this.multiButton_Click);
            // 
            // maisButton
            // 
            this.maisButton.Location = new System.Drawing.Point(171, 259);
            this.maisButton.Name = "maisButton";
            this.maisButton.Size = new System.Drawing.Size(50, 42);
            this.maisButton.TabIndex = 16;
            this.maisButton.Text = "+";
            this.maisButton.UseVisualStyleBackColor = true;
            this.maisButton.Click += new System.EventHandler(this.maisButton_Click);
            // 
            // menosButton
            // 
            this.menosButton.Location = new System.Drawing.Point(171, 211);
            this.menosButton.Name = "menosButton";
            this.menosButton.Size = new System.Drawing.Size(50, 42);
            this.menosButton.TabIndex = 17;
            this.menosButton.Text = "-";
            this.menosButton.UseVisualStyleBackColor = true;
            this.menosButton.Click += new System.EventHandler(this.menosButton_Click);
            // 
            // percentButton
            // 
            this.percentButton.Location = new System.Drawing.Point(227, 115);
            this.percentButton.Name = "percentButton";
            this.percentButton.Size = new System.Drawing.Size(50, 42);
            this.percentButton.TabIndex = 18;
            this.percentButton.Text = "%";
            this.percentButton.UseVisualStyleBackColor = true;
            this.percentButton.Click += new System.EventHandler(this.percentButton_Click);
            // 
            // igualButton
            // 
            this.igualButton.Location = new System.Drawing.Point(227, 211);
            this.igualButton.Name = "igualButton";
            this.igualButton.Size = new System.Drawing.Size(50, 90);
            this.igualButton.TabIndex = 19;
            this.igualButton.Text = "=";
            this.igualButton.UseVisualStyleBackColor = true;
            this.igualButton.Click += new System.EventHandler(this.igualButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 321);
            this.Controls.Add(this.igualButton);
            this.Controls.Add(this.percentButton);
            this.Controls.Add(this.menosButton);
            this.Controls.Add(this.maisButton);
            this.Controls.Add(this.multiButton);
            this.Controls.Add(this.divButton);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.doisButton);
            this.Controls.Add(this.tresButton);
            this.Controls.Add(this.zeroButton);
            this.Controls.Add(this.quatroButton);
            this.Controls.Add(this.cincoButton);
            this.Controls.Add(this.seisButton);
            this.Controls.Add(this.umButton);
            this.Controls.Add(this.seteButton);
            this.Controls.Add(this.oitoButton);
            this.Controls.Add(this.noveButton);
            this.Controls.Add(this.cButton);
            this.Controls.Add(this.ceButton);
            this.Controls.Add(this.displayLabel);
            this.Name = "Form1";
            this.Text = "Calculadora";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label displayLabel;
        private System.Windows.Forms.Button ceButton;
        private System.Windows.Forms.Button cButton;
        private System.Windows.Forms.Button noveButton;
        private System.Windows.Forms.Button oitoButton;
        private System.Windows.Forms.Button seteButton;
        private System.Windows.Forms.Button umButton;
        private System.Windows.Forms.Button seisButton;
        private System.Windows.Forms.Button cincoButton;
        private System.Windows.Forms.Button quatroButton;
        private System.Windows.Forms.Button zeroButton;
        private System.Windows.Forms.Button tresButton;
        private System.Windows.Forms.Button doisButton;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button divButton;
        private System.Windows.Forms.Button multiButton;
        private System.Windows.Forms.Button maisButton;
        private System.Windows.Forms.Button menosButton;
        private System.Windows.Forms.Button percentButton;
        private System.Windows.Forms.Button igualButton;
    }
}

